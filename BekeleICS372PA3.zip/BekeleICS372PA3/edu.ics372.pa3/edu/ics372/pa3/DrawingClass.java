package edu.ics372.pa3;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.geometry.Point2D;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * This is javaFX class that is implemented to draw a 'T' using users mouse
 * click as an input for two points. It consists of methods that handle the
 * mouse click, the drawing and labeling of the points.
 * 
 * @author Fraol Bekele 
 * Programming Assignment 3 
 * February 3. 2022
 *
 */
public class DrawingClass extends Application implements EventHandler<Event> {

	// Constants for width and height for canvas
	private static final int CANVAS_WIDTH = 900;
	private static final int CANVAS_HEIGHT = 700;

	// Instance variables
	private Canvas canvas;
	private Button drawButton;
	private Button exitButton;
	private GraphicsContext gc;
	private int mouseClickCount;
	private Point2D point1;
	private Point2D point2;

	/**
	 * Default constructor Initialize exit button and exit button
	 * 
	 */
	public DrawingClass() {
		// Instantiate canvas and buttons
		this.canvas = new Canvas(CANVAS_WIDTH, CANVAS_HEIGHT);
		this.drawButton = new Button("Draw");
		this.exitButton = new Button("Exit");

		// Get GraphicsContext of canvas
		this.gc = this.canvas.getGraphicsContext2D();

		// Add listener to the buttons
		this.drawButton.addEventHandler(ActionEvent.ACTION, this);
		this.exitButton.addEventHandler(ActionEvent.ACTION, this);

		// Add mouse listener for canvas
		this.canvas.addEventHandler(MouseEvent.MOUSE_CLICKED, this);

		// Initialize mouseClickCount to zero
		this.mouseClickCount = 0;
	}

	@Override
	public void start(Stage stage) throws Exception {
		// Generate UI
		VBox root = getUI();

		// Create scene to hold the user interface
		Scene scene = new Scene(root);

		// Set scene on primaryStage
		stage.setScene(scene);

		// Show primaryStage
		stage.show();
	}

	/**
	 * This method creates and returns a VBox containing the user interface for the
	 * program.
	 */
	private VBox getUI() {
		VBox vBox = new VBox();
		vBox.getChildren().add(this.canvas);
		HBox buttonBox = new HBox();
		buttonBox.getChildren().addAll(this.drawButton, this.exitButton);

		vBox.getChildren().add(buttonBox);
		return vBox;
	}

	// This method performs action based on the button clicked.
	@Override
	public void handle(Event event) {
		EventType eventType = event.getEventType();

		// This Checks which event is triggered
		if (eventType == ActionEvent.ACTION)
			handleButtonEvent((ActionEvent) event);
		else if (eventType == MouseEvent.MOUSE_CLICKED)
			handleMouseClickEvent((MouseEvent) event);
	}

	/**
	 * This method handles the button click events. It checks what button is
	 * clicked. It also calls the drawT method to draw a T if the mouse click count
	 * is more than 2
	 */
	private void handleButtonEvent(ActionEvent actionEvent) {
		// Get which button is clicked
		Button button = (Button) actionEvent.getSource();

		if (button == this.exitButton) {
			System.exit(0); // to exit program

		} else if (button == this.drawButton) {
			if (this.mouseClickCount >= 2) {

				// method to draw
				drawT();
				this.mouseClickCount = 0;
				// Set point1 and point2 to null
				this.point1 = null;
				this.point2 = null;
			}
		}
	}

	/**
	 * This method handles the mouse click event. It Increment mouseClickCount by 1
	 * and odd clicks to point1 and even clicks to point2
	 */
	private void handleMouseClickEvent(MouseEvent me) {
		this.mouseClickCount += 1;
		if ((this.mouseClickCount % 2) == 1)
			this.point1 = new Point2D(me.getX(), me.getY());
		else // Set point2 for even mouseClickCount
			this.point2 = new Point2D(me.getX(), me.getY());
	}

	/**
	 * A method that draws a T. It draws a horizontal or vertical line based the
	 * users mouse click which are point1 and point2
	 * 
	 */
	private void drawT() {
		if (this.point1.getY() == this.point2.getY()) { // Check if p1 and p2 form a horizontal line
			// Draws horizontal line
			this.gc.strokeLine(this.point1.getX(), this.point1.getY(), this.point2.getX(), this.point2.getY());

		} else if (this.point1.getX() == this.point2.getX()) { // Vertical line

			// Draws vertical line
			this.gc.strokeLine(this.point1.getX(), this.point1.getY(), this.point2.getX(), this.point2.getY());

		} else { // otherwise draw T
			// Check if point2 one is above point2
			if (this.point1.getY() < this.point2.getY()) {

				// Finds the middle point which is the intersection between the two points T
				Point2D interPt = new Point2D(this.point2.getX(), this.point1.getY());

				// Draw line from point2 to intersection
				this.gc.strokeLine(this.point2.getX(), this.point2.getY(), interPt.getX(), interPt.getY());

				// Draw horizontal line of 'T' from point1
				this.gc.strokeLine(this.point1.getX(), this.point1.getY(), (2 * interPt.getX()) - this.point1.getX(),
						this.point1.getY());

			} else {

				// Find the intersecting point of point1 and point2 which will form a T
				Point2D interPt = new Point2D(this.point1.getX(), this.point2.getY());

				// Draw line from p1 to interPt i.e. the vertical ine of 'T'
				this.gc.strokeLine(this.point1.getX(), this.point1.getY(), interPt.getX(), interPt.getY());

				// Draw horizontal line of T from point2
				this.gc.strokeLine(this.point2.getX(), this.point2.getY(), (2 * interPt.getX()) - this.point2.getX(),
						this.point2.getY());
			}

		}
		// Calls the method drawLabels to label the points clicked
		drawLabels();

	}

	/*
	 * This method draws the labels for point1 and point2
	 */
	private void drawLabels() {
		// Check if p1 is to the left of p2
		if (this.point1.getX() < this.point2.getX()) {

			// Check if p1 is above p2
			if (this.point1.getY() < this.point2.getY()) {

				// Draw p1 and p2
				this.gc.fillText("p1", this.point1.getX(), this.point1.getY() - 5);
				this.gc.fillText("p2", this.point2.getX() + 2, this.point2.getY() - 2);

			} else {
				// Draw p2
				this.gc.fillText("p2", this.point2.getX() - 5, this.point2.getY() - 5);

				// Draw p1
				// If p1 is below p2
				if (this.point1.getY() > this.point2.getY())
					this.gc.fillText("p1", this.point1.getX() + 2, this.point1.getY() - 2);
				else // For horizontal line
					this.gc.fillText("p1", this.point1.getX(), this.point1.getY() - 5);
			}

		} else if (this.point1.getX() == this.point2.getX()) { // Vertical line

			// Draw p1 and p2
			this.gc.fillText("p1", this.point1.getX() + 2, this.point1.getY() - 2);
			this.gc.fillText("p2", this.point2.getX() + 2, this.point2.getY() - 2);

		} else { // if p1 is to the right of p2

			// Check if p1 is above p2
			if (this.point1.getY() < this.point2.getY()) {

				// Draw p1 and p2
				this.gc.fillText("p1", this.point1.getX() - 5, this.point1.getY() - 5);
				this.gc.fillText("p2", this.point2.getX() + 2, this.point2.getY() - 2);

			} else {
				// Draw p2
				this.gc.fillText("p2", this.point2.getX() - 5, this.point2.getY() - 5);

				// Draw p1
				// If p1 is below p2
				if (this.point1.getY() > this.point2.getY())
					this.gc.fillText("p1", this.point1.getX() + 2, this.point1.getY() - 2);
				else // For horizontal line
					this.gc.fillText("p1", this.point1.getX() - 5, this.point1.getY() - 5);
			}
		}
	}

	/*
	 * main argument method to start the application
	 */
	public static void main(String[] args) {
		launch(args);
	}
}
