module edu.ics372.pa3 {
	
	requires javafx.graphics;

	  requires javafx.controls;

	  requires javafx.base;

	  exports edu.ics372.pa3 to javafx.graphics;


}